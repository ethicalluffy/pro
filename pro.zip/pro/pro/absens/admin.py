from django.contrib import admin
from models import ppl

admin.site.register(ppl)
