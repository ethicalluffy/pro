from django.db import models

class ppl(models.Model):
	name =models.CharField(max_length=30)
	lname=models.CharField(max_length=30)
	pm=models.EmailField()
	pr=models.CharField(max_length=1)