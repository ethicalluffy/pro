from django.shortcuts import render
from models import ppl
from django.core.mail import EmailMessage
def absens(pm,pr):
    ma= ppl.pr.objects.all()
    for i in ma:
    	if pr = "A":
    		ka=str(ppl.pm)
    		email=EmailMessage(
    			'administration du lycée salem cité riadh ',
    			'Nous avons desolé de vous informer que votre fils a été marqué absent , merci de nous contactez le plus taux possible ',
    			'amindev.kh@gmail.com',
    			[ka],)
    		email.send()

              